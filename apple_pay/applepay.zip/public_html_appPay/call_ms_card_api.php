<?php
echo 'call_ms_card_api'.'<hr>';
echo '<h3>Apple Pay Response</h3>';
echo '<pre>';print_r($_GET);